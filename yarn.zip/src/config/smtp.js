// module.exports = {
//     host: 'smtp.gmail.com',
//     port:  587, 
//     user: 'noreply.smartstore@gmail.com',
//     pass: 'befkyfqggjseyurk'
// }

module.exports = {
    host: 'smtp.zoho.com',
    port:  587, 
    user: 'no-reply@safyra.com.br',
    pass: '2KQqRrwQxxgD'
    //pass: '#EP+$ovEvu$ruH9C0bRo'
}