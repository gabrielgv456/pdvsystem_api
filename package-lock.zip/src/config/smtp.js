// module.exports = {
//     host: 'smtp.gmail.com',
//     port:  587, 
//     user: 'noreply.smartstore@gmail.com',
//     pass: 'befkyfqggjseyurk'
// }

export const host = 'smtp.zoho.com';
export const port = 587;
export const user = 'no-reply@safyra.com.br';
export const pass = '2KQqRrwQxxgD';