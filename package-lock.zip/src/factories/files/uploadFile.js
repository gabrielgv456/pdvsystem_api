//@ts-check

import prisma from '../../services/prisma/index.js'

/**
 * @param {import('express').Request} request
 * @param {import('express').Response} response
 */

export default async function uploadFile(request, response) {
    try {
        const dataUpload = request.query

        if (!request.file) { throw new Error('Falha ao salvar o arquivo') }

        const createdImage = await prisma.images.create({
            data: {
                description: (dataUpload.description?.toString()) ?? null,
                owner: (dataUpload.owner?.toString()) ?? null,
                nameFile: request.file.filename,
                host: (dataUpload.host?.toString()) ?? null,
                path: '/' + (request.file.destination)
            }
        })

        const url = createdImage.host + (createdImage.path ?? '') + createdImage.nameFile

        if (dataUpload.module === 'User') {
            if (!dataUpload.userId) { throw new Error('userId não informado!') }
            const updateUrl = await prisma.user.update({
                where: {
                    id: parseInt(dataUpload.userId.toString())
                }, data: {
                    urlLogo: url
                }
            })
        }
        
        return response.json({
            Success: true,
            url,
            id: createdImage.id
        })

    } catch (error) {
        return response.status(400).json({ Success: false, erro: error.message })
    }
}