//@ts-check
import path, { dirname } from 'path';
import fs from 'fs/promises'
import prisma from '../../services/prisma/index.js';

/**
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 */

export const deleteFile = async (req, res) => {
    try {
        if (!req.query.imageId) throw new Error('Informe o imageId')
        if (!req.query.userId) throw new Error('Informe o userId')

        const imageId = parseInt(req.query.imageId?.toString())

        const user = await prisma.user.findUnique({ where: { id: parseInt(req.query.userId.toString()) } })
        if (!user) throw new Error('Não foi encontrado usuario com id informado!')

        const image = await prisma.images.findUnique({ where: { id: imageId } })
        if (image?.owner !== 'local') { throw new Error('No momento apenas existe opção de exclusão local!') }
        if (!image.nameFile) throw new Error('Não foi encontrado o nome do arquivo!')

        const filePath = path.resolve(dirname('')) + path.join(image?.path ?? '', String(image?.nameFile));

        await fs.access(filePath).catch(() => {
            throw new Error('Falha ao encontrar arquivo')
        });

        await fs.unlink(filePath);
        await prisma.images.delete({ where: { id: imageId } })

        return res.status(200).json({ Success: true, erro: 'Arquivo excluído com sucesso.' });

    } catch (error) {
        return res.status(error.status ?? 400).json({ Success: false, erro: 'Erro ao excluir o arquivo! ' + error.message });
    }
}